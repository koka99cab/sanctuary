package com.koka.sanctuary.worldgen;

import net.minecraft.world.dimension.DimensionOptionsRegistryHolder;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.chunk.NoiseChunkGenerator;

public final class SanctuaryWorldgen {
	public static final double ADVANCED_WORLDGEN_START_DISTANCE = 10_000_000.0D;
	public static final double ADVANCED_WORLDGEN_TRANSITION_WIDTH = 4_096.0D;

	private SanctuaryWorldgen() {
	}

	public static boolean isSanctuaryDimensions(DimensionOptionsRegistryHolder dimensions) {
		return isSanctuaryGenerator(dimensions.getChunkGenerator());
	}

	public static boolean isSanctuaryGenerator(ChunkGenerator generator) {
		return generator instanceof NoiseChunkGenerator noiseGenerator
			&& noiseGenerator.getBiomeSource() instanceof SanctuaryBiomeSource;
	}

	public static SanctuaryBiomeSource getSanctuaryBiomeSource(ChunkGenerator generator) {
		if (generator instanceof NoiseChunkGenerator noiseGenerator
			&& noiseGenerator.getBiomeSource() instanceof SanctuaryBiomeSource sanctuaryBiomeSource) {
			return sanctuaryBiomeSource;
		}

		throw new IllegalArgumentException("Chunk generator is not a Sanctuary generator");
	}

	public static boolean usesAdvancedWorldgen(double distanceFromOrigin) {
		return distanceFromOrigin >= ADVANCED_WORLDGEN_START_DISTANCE;
	}

	public static double distanceToOrigin(double blockX, double blockZ) {
		return Math.sqrt(blockX * blockX + blockZ * blockZ);
	}

	public static SanctuaryShellCoordinates projectToAdvancedShell(double blockX, double blockZ) {
		double worldDistance = distanceToOrigin(blockX, blockZ);
		double angle = Math.atan2(blockZ, blockX);
		double localDistance = Math.max(0.0D, worldDistance - ADVANCED_WORLDGEN_START_DISTANCE);
		double localBlockX = Math.cos(angle) * localDistance;
		double localBlockZ = Math.sin(angle) * localDistance;
		return new SanctuaryShellCoordinates(worldDistance, localDistance, localBlockX, localBlockZ);
	}
}
