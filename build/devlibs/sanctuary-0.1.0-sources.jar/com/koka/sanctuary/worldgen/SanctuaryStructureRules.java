package com.koka.sanctuary.worldgen;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.chunk.VerticalBlockSample;
import net.minecraft.world.gen.noise.NoiseConfig;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureType;

public final class SanctuaryStructureRules {
	private static final int[][] SUPPORT_SAMPLE_OFFSETS = {
		{4, 4},
		{12, 4},
		{4, 12},
		{12, 12},
		{8, 8}
	};
	private static final int MIN_TERRAIN_HEIGHT_ABOVE_BOTTOM = 16;
	private static final int SUPPORT_SCAN_DEPTH = 48;
	private static final StructureProfile DEFAULT_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		2,
		1,
		24,
		6,
		14,
		0,
		4,
		0
	);
	private static final StructureProfile SETTLEMENT_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		4,
		0,
		36,
		7,
		12,
		0,
		4,
		0
	);
	private static final StructureProfile MONUMENT_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		3,
		1,
		32,
		8,
		16,
		0,
		5,
		0
	);
	private static final StructureProfile PORTAL_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		3,
		0,
		28,
		7,
		12,
		0,
		4,
		0
	);
	private static final StructureProfile SUBTERRANEAN_PROFILE = new StructureProfile(
		AnchorMode.INTERIOR,
		3,
		2,
		44,
		12,
		20,
		14,
		8,
		64
	);
	private static final StructureProfile BURIED_PROFILE = new StructureProfile(
		AnchorMode.INTERIOR,
		3,
		0,
		18,
		6,
		10,
		4,
		3,
		20
	);

	private SanctuaryStructureRules() {
	}

	public static Optional<Structure.StructurePosition> adapt(Structure structure, Structure.Context context, Structure.StructurePosition position) {
		if (!SanctuaryWorldgen.isSanctuaryGenerator(context.chunkGenerator())) {
			return Optional.of(position);
		}

		StructureProfile profile = profileFor(structure);
		TerrainReport terrain = analyzeTerrain(context, profile);
		if (!terrain.isSupported(profile)) {
			return Optional.empty();
		}

		BlockPos originalPos = position.position();
		int adjustedY = switch (profile.anchorMode()) {
			case KEEP -> originalPos.getY();
			case INTERIOR -> computeInteriorAnchorY(profile, terrain, originalPos.getY());
		};
		if (adjustedY == originalPos.getY()) {
			return Optional.of(position);
		}

		BlockPos adjustedPos = new BlockPos(originalPos.getX(), adjustedY, originalPos.getZ());
		return Optional.of(new Structure.StructurePosition(adjustedPos, position.generator()));
	}

	private static StructureProfile profileFor(Structure structure) {
		StructureType<?> type = structure.getType();
		if (type == StructureType.MINESHAFT || type == StructureType.STRONGHOLD) {
			return SUBTERRANEAN_PROFILE;
		}
		if (type == StructureType.BURIED_TREASURE) {
			return BURIED_PROFILE;
		}
		if (type == StructureType.JIGSAW) {
			return SETTLEMENT_PROFILE;
		}
		if (
			type == StructureType.DESERT_PYRAMID
				|| type == StructureType.JUNGLE_TEMPLE
				|| type == StructureType.IGLOO
				|| type == StructureType.SWAMP_HUT
				|| type == StructureType.WOODLAND_MANSION
				|| type == StructureType.OCEAN_MONUMENT
				|| type == StructureType.OCEAN_RUIN
				|| type == StructureType.SHIPWRECK
		) {
			return MONUMENT_PROFILE;
		}
		if (type == StructureType.RUINED_PORTAL) {
			return PORTAL_PROFILE;
		}

		return DEFAULT_PROFILE;
	}

	private static TerrainReport analyzeTerrain(Structure.Context context, StructureProfile profile) {
		ChunkGenerator chunkGenerator = context.chunkGenerator();
		ChunkPos chunkPos = context.chunkPos();
		HeightLimitView world = context.world();
		NoiseConfig noiseConfig = context.noiseConfig();
		int bottomY = world.getBottomY();
		List<TerrainSample> samples = new ArrayList<>(SUPPORT_SAMPLE_OFFSETS.length);
		int supportedColumns = 0;
		int deepColumns = 0;
		int totalThickness = 0;
		int surfaceYSum = 0;
		int surfaceYCount = 0;
		TerrainSample bestSurfaceSample = null;
		TerrainSample bestDeepSample = null;

		for (int[] sampleOffset : SUPPORT_SAMPLE_OFFSETS) {
			int sampleX = chunkPos.getStartX() + sampleOffset[0];
			int sampleZ = chunkPos.getStartZ() + sampleOffset[1];
			int topY = chunkGenerator.getHeightInGround(sampleX, sampleZ, Heightmap.Type.WORLD_SURFACE_WG, world, noiseConfig);
			if (topY <= bottomY + MIN_TERRAIN_HEIGHT_ABOVE_BOTTOM) {
				continue;
			}

			int thickness = measureSurfaceThickness(chunkGenerator.getColumnSample(sampleX, sampleZ, world, noiseConfig), topY - 1, bottomY);
			TerrainSample sample = new TerrainSample(sampleX, sampleZ, topY, thickness);
			samples.add(sample);
			surfaceYSum += topY;
			surfaceYCount++;

			if (thickness >= profile.minSurfaceThickness()) {
				supportedColumns++;
				if (bestSurfaceSample == null || thickness > bestSurfaceSample.thickness()) {
					bestSurfaceSample = sample;
				}
			}

			if (thickness >= profile.minDeepSurfaceThickness()) {
				deepColumns++;
				if (bestDeepSample == null || thickness > bestDeepSample.thickness()) {
					bestDeepSample = sample;
				}
			}

			totalThickness += thickness;
		}

		int averageSurfaceY = surfaceYCount == 0 ? bottomY : Math.round((float) surfaceYSum / surfaceYCount);
		return new TerrainReport(bottomY, supportedColumns, deepColumns, totalThickness, averageSurfaceY, bestSurfaceSample, bestDeepSample, samples);
	}

	private static int computeInteriorAnchorY(StructureProfile profile, TerrainReport terrain, int originalY) {
		TerrainSample anchorSample = terrain.bestDeepSample() != null ? terrain.bestDeepSample() : terrain.bestSurfaceSample();
		if (anchorSample == null) {
			return originalY;
		}

		int maxInset = Math.max(profile.surfaceCover(), anchorSample.thickness() - profile.surfaceCover());
		int inset = Math.min(profile.targetInset(), maxInset);
		int targetY = anchorSample.topY() - inset;
		int maxRaisedY = originalY + profile.maxRaise();
		return Math.min(Math.max(originalY, targetY), maxRaisedY);
	}

	private static int measureSurfaceThickness(VerticalBlockSample sample, int topBlockY, int bottomY) {
		int minY = Math.max(bottomY, topBlockY - SUPPORT_SCAN_DEPTH);
		int thickness = 0;

		for (int y = topBlockY; y >= minY; y--) {
			if (!sample.getState(y).blocksMovement()) {
				break;
			}

			thickness++;
		}

		return thickness;
	}

	private enum AnchorMode {
		KEEP,
		INTERIOR
	}

	private record StructureProfile(
		AnchorMode anchorMode,
		int minSupportedColumns,
		int minDeepColumns,
		int minTotalThickness,
		int minSurfaceThickness,
		int minDeepSurfaceThickness,
		int targetInset,
		int surfaceCover,
		int maxRaise
	) {
	}

	private record TerrainSample(int x, int z, int topY, int thickness) {
	}

	private record TerrainReport(
		int bottomY,
		int supportedColumns,
		int deepColumns,
		int totalThickness,
		int averageSurfaceY,
		TerrainSample bestSurfaceSample,
		TerrainSample bestDeepSample,
		List<TerrainSample> samples
	) {
		private boolean isSupported(StructureProfile profile) {
			return supportedColumns >= profile.minSupportedColumns()
				&& (deepColumns >= profile.minDeepColumns() || totalThickness >= profile.minTotalThickness());
		}
	}
}
