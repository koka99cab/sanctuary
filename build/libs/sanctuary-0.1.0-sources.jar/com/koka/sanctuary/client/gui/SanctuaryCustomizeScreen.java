package com.koka.sanctuary.client.gui;

import com.koka.sanctuary.worldgen.MainIslandPreset;
import com.koka.sanctuary.worldgen.SanctuaryBiomeSource;
import com.koka.sanctuary.worldgen.SanctuaryChunkGeneratorSettingsFactory;
import com.koka.sanctuary.worldgen.SanctuaryWorldgen;
import com.koka.sanctuary.worldgen.SanctuaryWorldgenOptions;
import com.koka.sanctuary.worldgen.VerticalityProfile;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_1959;
import net.minecraft.class_2561;
import net.minecraft.class_2794;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_357;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_525;
import net.minecraft.class_5676;
import net.minecraft.class_6379;
import net.minecraft.class_6880;
import net.minecraft.class_7193;

public final class SanctuaryCustomizeScreen extends class_437 {
	private static final int WIDGET_WIDTH = 310;
	private static final int WIDGET_HEIGHT = 20;
	private static final int ROW_SPACING = 24;

	private final class_525 parent;
	private final SanctuaryBiomeSource sanctuaryBiomeSource;
	private final List<class_6880<class_1959>> startingBiomeOptions;
	private class_6880<class_1959> selectedStarterBiome;
	private MainIslandPreset mainIslandPreset;
	private double sanctuaryZoneScale;
	private double starterIslandScale;
	private double archipelagoSize;
	private double archipelagoSpacing;
	private double monolithGapScale;
	private int vanillaFloatingIslandsStartRadius;
	private boolean deepslateCore;
	private VerticalityProfile verticalityProfile;
	private double monolithMassHeight;
	private double monolithShoulderWidth;
	private int fracturedIslandCount;
	private double fracturedRingRadius;
	private double hollowVoidSize;
	private double hollowRingThickness;
	private int spireCount;
	private double spireHeight;
	private OptionsListWidget optionsList;
	private double optionsScrollY;

	public SanctuaryCustomizeScreen(class_525 parent, class_7193 generatorOptionsHolder) {
		super(class_2561.method_43471("screen.sanctuary.customize.title"));
		this.parent = parent;
		class_2794 chunkGenerator = generatorOptionsHolder.comp_1028().method_45513();
		this.sanctuaryBiomeSource = SanctuaryWorldgen.getSanctuaryBiomeSource(chunkGenerator);
		SanctuaryWorldgenOptions currentOptions = this.sanctuaryBiomeSource.options();
		this.startingBiomeOptions = this.sanctuaryBiomeSource.getStartingBiomeCandidates();
		this.selectedStarterBiome = currentOptions.starterBiome();
		this.mainIslandPreset = currentOptions.mainIslandPreset();
		this.sanctuaryZoneScale = currentOptions.sanctuaryZoneScale();
		this.starterIslandScale = currentOptions.starterIslandScale();
		this.archipelagoSize = currentOptions.archipelagoSize();
		this.archipelagoSpacing = currentOptions.archipelagoSpacing();
		this.monolithGapScale = currentOptions.monolithGapScale();
		this.vanillaFloatingIslandsStartRadius = currentOptions.vanillaFloatingIslandsStartRadius();
		this.deepslateCore = currentOptions.deepslateCore();
		this.verticalityProfile = currentOptions.verticalityProfile();
		this.monolithMassHeight = currentOptions.monolithMassHeight();
		this.monolithShoulderWidth = currentOptions.monolithShoulderWidth();
		this.fracturedIslandCount = currentOptions.fracturedIslandCount();
		this.fracturedRingRadius = currentOptions.fracturedRingRadius();
		this.hollowVoidSize = currentOptions.hollowVoidSize();
		this.hollowRingThickness = currentOptions.hollowRingThickness();
		this.spireCount = currentOptions.spireCount();
		this.spireHeight = currentOptions.spireHeight();
	}

	@Override
	protected void method_25426() {
		super.method_25426();
		int listTop = 44;
		int buttonY = this.field_22790 - 28;
		int listHeight = Math.max(72, buttonY - listTop - 18);
		this.optionsList = new OptionsListWidget(this.field_22787, this.field_22789, listHeight, listTop);
		this.populateOptionsList();
		this.optionsList.method_44382(Math.min(this.optionsScrollY, this.optionsList.method_44390()));
		this.method_37063(this.optionsList);

		int buttonWidth = 150;
		int gap = 10;
		int buttonsLeft = (this.field_22789 - (buttonWidth * 2 + gap)) / 2;
		this.method_37063(
			class_4185
				.method_46430(class_5244.field_24334, button -> this.applyAndClose())
				.method_46434(buttonsLeft, buttonY, buttonWidth, WIDGET_HEIGHT)
				.method_46431()
		);
		this.method_37063(
			class_4185
				.method_46430(class_5244.field_24335, button -> this.method_25419())
				.method_46434(buttonsLeft + buttonWidth + gap, buttonY, buttonWidth, WIDGET_HEIGHT)
				.method_46431()
		);
	}

	private void populateOptionsList() {
		this.addOption(
			class_5676
				.method_32606(this::getPresetDisplayName, this.mainIslandPreset)
				.method_32620(Arrays.asList(MainIslandPreset.values()))
				.method_32617(0, 0, WIDGET_WIDTH, WIDGET_HEIGHT, class_2561.method_43471("screen.sanctuary.customize.main_island_preset"), (button, preset) -> {
					this.mainIslandPreset = preset;
					this.rebuildOptionsList();
				})
		);
		this.addOption(
			class_5676
				.method_32606(SanctuaryBiomeSource::getBiomeDisplayName, this.selectedStarterBiome)
				.method_32620(this.startingBiomeOptions)
				.method_32617(0, 0, WIDGET_WIDTH, WIDGET_HEIGHT, class_2561.method_43471("screen.sanctuary.customize.starting_biome"), (button, biome) -> this.selectedStarterBiome = biome)
		);
		this.addOption(
			class_5676
				.method_32606(value -> value ? class_5244.field_24332 : class_5244.field_24333, this.deepslateCore)
				.method_32620(List.of(Boolean.TRUE, Boolean.FALSE))
				.method_32617(0, 0, WIDGET_WIDTH, WIDGET_HEIGHT, class_2561.method_43471("screen.sanctuary.customize.deepslate_core"), (button, value) -> this.deepslateCore = value)
		);
		this.addOption(
			class_5676
				.method_32606(this::getVerticalityDisplayName, this.verticalityProfile)
				.method_32620(Arrays.asList(VerticalityProfile.values()))
				.method_32617(0, 0, WIDGET_WIDTH, WIDGET_HEIGHT, class_2561.method_43471("screen.sanctuary.customize.verticality_profile"), (button, value) -> this.verticalityProfile = value)
		);
		this.addOption(new NumericSlider(
			class_2561.method_43471("screen.sanctuary.customize.sanctuary_zone_scale"),
			SanctuaryWorldgenOptions.MIN_SANCTUARY_ZONE_SCALE,
			SanctuaryWorldgenOptions.MAX_SANCTUARY_ZONE_SCALE,
			this.sanctuaryZoneScale,
			true,
			value -> this.sanctuaryZoneScale = value
		));
		this.addOption(new NumericSlider(
			class_2561.method_43471("screen.sanctuary.customize.starter_island_scale"),
			SanctuaryWorldgenOptions.MIN_STARTER_ISLAND_SCALE,
			SanctuaryWorldgenOptions.MAX_STARTER_ISLAND_SCALE,
			this.starterIslandScale,
			true,
			value -> this.starterIslandScale = value
		));
		this.addOption(new NumericSlider(
			class_2561.method_43471("screen.sanctuary.customize.archipelago_size"),
			SanctuaryWorldgenOptions.MIN_ARCHIPELAGO_SIZE,
			SanctuaryWorldgenOptions.MAX_ARCHIPELAGO_SIZE,
			this.archipelagoSize,
			true,
			value -> this.archipelagoSize = value
		));
		this.addOption(new NumericSlider(
			class_2561.method_43471("screen.sanctuary.customize.archipelago_spacing"),
			SanctuaryWorldgenOptions.MIN_ARCHIPELAGO_SPACING,
			SanctuaryWorldgenOptions.MAX_ARCHIPELAGO_SPACING,
			this.archipelagoSpacing,
			false,
			value -> this.archipelagoSpacing = value
		));
		this.addOption(new NumericSlider(
			class_2561.method_43471("screen.sanctuary.customize.monolith_gap_scale"),
			SanctuaryWorldgenOptions.MIN_MONOLITH_GAP_SCALE,
			SanctuaryWorldgenOptions.MAX_MONOLITH_GAP_SCALE,
			this.monolithGapScale,
			true,
			value -> this.monolithGapScale = value
		));
		this.addOption(new IntegerSlider(
			class_2561.method_43471("screen.sanctuary.customize.vanilla_floating_islands_start_radius"),
			SanctuaryWorldgenOptions.MIN_VANILLA_FLOATING_ISLANDS_START_RADIUS,
			SanctuaryWorldgenOptions.MAX_VANILLA_FLOATING_ISLANDS_START_RADIUS,
			this.vanillaFloatingIslandsStartRadius,
			value -> this.vanillaFloatingIslandsStartRadius = value
		));
		this.addPresetSpecificWidgets();
	}

	private void addPresetSpecificWidgets() {
		switch (this.mainIslandPreset) {
			case MONOLITH -> {
				this.addOption(new NumericSlider(
					class_2561.method_43471("screen.sanctuary.customize.monolith_mass_height"),
					SanctuaryWorldgenOptions.MIN_MONOLITH_MASS_HEIGHT,
					SanctuaryWorldgenOptions.MAX_MONOLITH_MASS_HEIGHT,
					this.monolithMassHeight,
					true,
					value -> this.monolithMassHeight = value
				));
				this.addOption(new NumericSlider(
					class_2561.method_43471("screen.sanctuary.customize.monolith_shoulder_width"),
					SanctuaryWorldgenOptions.MIN_MONOLITH_SHOULDER_WIDTH,
					SanctuaryWorldgenOptions.MAX_MONOLITH_SHOULDER_WIDTH,
					this.monolithShoulderWidth,
					true,
					value -> this.monolithShoulderWidth = value
				));
			}
			case FRACTURED_ARCHIPELAGO -> {
				this.addOption(new IntegerSlider(
					class_2561.method_43471("screen.sanctuary.customize.fractured_island_count"),
					SanctuaryWorldgenOptions.MIN_FRACTURED_ISLAND_COUNT,
					SanctuaryWorldgenOptions.MAX_FRACTURED_ISLAND_COUNT,
					this.fracturedIslandCount,
					value -> this.fracturedIslandCount = value
				));
				this.addOption(new NumericSlider(
					class_2561.method_43471("screen.sanctuary.customize.fractured_ring_radius"),
					SanctuaryWorldgenOptions.MIN_FRACTURED_RING_RADIUS,
					SanctuaryWorldgenOptions.MAX_FRACTURED_RING_RADIUS,
					this.fracturedRingRadius,
					true,
					value -> this.fracturedRingRadius = value
				));
			}
			case HOLLOW_CROWN -> {
				this.addOption(new NumericSlider(
					class_2561.method_43471("screen.sanctuary.customize.hollow_void_size"),
					SanctuaryWorldgenOptions.MIN_HOLLOW_VOID_SIZE,
					SanctuaryWorldgenOptions.MAX_HOLLOW_VOID_SIZE,
					this.hollowVoidSize,
					true,
					value -> this.hollowVoidSize = value
				));
				this.addOption(new NumericSlider(
					class_2561.method_43471("screen.sanctuary.customize.hollow_ring_thickness"),
					SanctuaryWorldgenOptions.MIN_HOLLOW_RING_THICKNESS,
					SanctuaryWorldgenOptions.MAX_HOLLOW_RING_THICKNESS,
					this.hollowRingThickness,
					true,
					value -> this.hollowRingThickness = value
				));
			}
			case SPIRE_GARDEN -> {
				this.addOption(new IntegerSlider(
					class_2561.method_43471("screen.sanctuary.customize.spire_count"),
					SanctuaryWorldgenOptions.MIN_SPIRE_COUNT,
					SanctuaryWorldgenOptions.MAX_SPIRE_COUNT,
					this.spireCount,
					value -> this.spireCount = value
				));
				this.addOption(new NumericSlider(
					class_2561.method_43471("screen.sanctuary.customize.spire_height"),
					SanctuaryWorldgenOptions.MIN_SPIRE_HEIGHT,
					SanctuaryWorldgenOptions.MAX_SPIRE_HEIGHT,
					this.spireHeight,
					true,
					value -> this.spireHeight = value
				));
			}
		}
	}

	private void addOption(class_339 widget) {
		this.optionsList.addOption(new OptionEntry(widget));
	}

	private void rebuildOptionsList() {
		if (this.optionsList != null) {
			this.optionsScrollY = this.optionsList.method_44387();
		}

		this.method_41843();
	}

	@Override
	public void method_25419() {
		if (this.field_22787 != null) {
			this.field_22787.method_1507(this.parent);
		}
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		this.renderStaticBackground(context, delta);
		super.method_25394(context, mouseX, mouseY, delta);
		int contentLeft = (this.field_22789 - WIDGET_WIDTH) / 2;
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 14, 0xFFFFFF);
		context.method_27535(
			this.field_22793,
			class_2561.method_43471("screen.sanctuary.customize.description"),
			contentLeft,
			28,
			0xAFAFAF
		);
		context.method_27535(
			this.field_22793,
			class_2561.method_43471("screen.sanctuary.customize.archipelago_hint"),
			contentLeft,
			this.field_22790 - 44,
			0x8F8F8F
		);
	}

	private void renderStaticBackground(class_332 context, float delta) {
		if (this.field_22787 != null && this.field_22787.field_1687 == null) {
			this.method_57728(context, delta);
			this.method_57735(context);
			return;
		}

		this.method_52752(context);
	}

	private void applyAndClose() {
		SanctuaryWorldgenOptions updatedOptions = new SanctuaryWorldgenOptions(
			this.selectedStarterBiome,
			this.sanctuaryZoneScale,
			this.starterIslandScale,
			this.archipelagoSize,
			this.archipelagoSpacing,
			this.monolithGapScale,
			this.vanillaFloatingIslandsStartRadius,
			this.deepslateCore,
			false,
			this.verticalityProfile,
			this.mainIslandPreset,
			this.monolithMassHeight,
			this.monolithShoulderWidth,
			this.fracturedIslandCount,
			this.fracturedRingRadius,
			this.hollowVoidSize,
			this.hollowRingThickness,
			this.spireCount,
			this.spireHeight
		);
		this.parent.method_48657().method_48700((registryManager, selectedDimensions) -> selectedDimensions.method_45522(
			registryManager,
			SanctuaryChunkGeneratorSettingsFactory.createGenerator(registryManager, selectedDimensions, updatedOptions)
		));
		this.method_25419();
	}

	private class_2561 getPresetDisplayName(MainIslandPreset preset) {
		return class_2561.method_43471("screen.sanctuary.customize.main_island_preset." + preset.method_15434());
	}

	private class_2561 getVerticalityDisplayName(VerticalityProfile profile) {
		return class_2561.method_43471("screen.sanctuary.customize.verticality_profile." + profile.method_15434());
	}

	private static final class OptionsListWidget extends class_4265<OptionEntry> {
		private OptionsListWidget(class_310 client, int width, int height, int y) {
			super(client, width, height, y, ROW_SPACING);
			this.field_22744 = false;
		}

		@Override
		public int method_25322() {
			return WIDGET_WIDTH;
		}

		@Override
		protected int method_65507() {
			return this.method_31383() + 10;
		}

		private void addOption(OptionEntry entry) {
			this.method_25321(entry);
		}
	}

	private static final class OptionEntry extends class_4265.class_4266<OptionEntry> {
		private final class_339 widget;
		private final List<class_339> children;

		private OptionEntry(class_339 widget) {
			this.widget = widget;
			this.children = List.of(widget);
		}

		@Override
		public void method_25343(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
			this.widget.method_55444(this.method_73387(), WIDGET_HEIGHT, this.method_73380(), this.method_73382() + 2);
			this.widget.method_25394(context, mouseX, mouseY, delta);
		}

		@Override
		public List<? extends class_364> method_25396() {
			return this.children;
		}

		@Override
		public List<? extends class_6379> method_37025() {
			return this.children;
		}
	}

	private static class NumericSlider extends class_357 {
		private final class_2561 label;
		private final double minValue;
		private final double maxValue;
		private final boolean multiplierFormat;
		private final java.util.function.DoubleConsumer onValueChanged;

		private NumericSlider(
			class_2561 label,
			double minValue,
			double maxValue,
			double initialValue,
			boolean multiplierFormat,
			java.util.function.DoubleConsumer onValueChanged
		) {
			super(0, 0, WIDGET_WIDTH, WIDGET_HEIGHT, label, normalize(initialValue, minValue, maxValue));
			this.label = label;
			this.minValue = minValue;
			this.maxValue = maxValue;
			this.multiplierFormat = multiplierFormat;
			this.onValueChanged = onValueChanged;
			this.method_25346();
		}

		@Override
		protected void method_25346() {
			this.method_25355(
				class_2561.method_43473()
					.method_10852(this.label)
					.method_27693(": ")
					.method_10852(class_2561.method_43470(this.formatValue()))
			);
		}

		@Override
		protected void method_25344() {
			this.onValueChanged.accept(this.getNumericValue());
		}

		private double getNumericValue() {
			return this.minValue + this.field_22753 * (this.maxValue - this.minValue);
		}

		private String formatValue() {
			double numericValue = this.getNumericValue();
			if (this.multiplierFormat) {
				return String.format(Locale.ROOT, "x%.2f", numericValue);
			}

			return String.format(Locale.ROOT, "%+.2f", numericValue);
		}

		private static double normalize(double value, double minValue, double maxValue) {
			if (maxValue <= minValue) {
				return 0.0D;
			}

			double normalized = (value - minValue) / (maxValue - minValue);
			return Math.max(0.0D, Math.min(1.0D, normalized));
		}
	}

	private static class IntegerSlider extends NumericSlider {
		private final class_2561 label;
		private final int minValue;
		private final int maxValue;
		private final java.util.function.IntConsumer onValueChanged;

		private IntegerSlider(
			class_2561 label,
			int minValue,
			int maxValue,
			int initialValue,
			java.util.function.IntConsumer onValueChanged
		) {
			super(label, minValue, maxValue, initialValue, false, value -> {});
			this.label = label;
			this.minValue = minValue;
			this.maxValue = maxValue;
			this.onValueChanged = onValueChanged;
			this.method_25346();
		}

		@Override
		protected void method_25346() {
			this.method_25355(
				class_2561.method_43473()
					.method_10852(this.label)
					.method_27693(": ")
					.method_10852(class_2561.method_43470(Integer.toString(this.getNumericValue())))
			);
		}

		@Override
		protected void method_25344() {
			int numericValue = this.getNumericValue();
			this.field_22753 = NumericSlider.normalize(numericValue, this.minValue, this.maxValue);
			this.onValueChanged.accept(numericValue);
			this.method_25346();
		}

		protected int getNumericValue() {
			return (int) Math.round(this.minValue + this.field_22753 * (this.maxValue - this.minValue));
		}
	}

}
