package com.koka.sanctuary.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_156;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2561;
import net.minecraft.class_4766;
import net.minecraft.class_6544;
import net.minecraft.class_6880;
import net.minecraft.class_6908;
import net.minecraft.class_8197;

public final class SanctuaryBiomeSource extends class_1966 {
	public static final MapCodec<SanctuaryBiomeSource> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
		class_8197.field_42987.fieldOf("fallback").forGetter(source -> source.fallback),
		class_1959.field_24677.fieldOf("meadow").forGetter(source -> source.meadow),
		class_1959.field_24677.fieldOf("birch_forest").forGetter(source -> source.birchForest),
		class_1959.field_24677.fieldOf("forest").forGetter(source -> source.forest),
		class_1959.field_24677.fieldOf("flower_forest").forGetter(source -> source.flowerForest),
		class_1959.field_24677.fieldOf("sunflower_plains").forGetter(source -> source.sunflowerPlains),
		class_1959.field_24677.fieldOf("windswept_hills").forGetter(source -> source.windsweptHills),
		SanctuaryWorldgenOptions.CODEC.optionalFieldOf("options").forGetter(source -> Optional.of(source.options)),
		Codec.DOUBLE.optionalFieldOf("fallback_scale", 0.42D).forGetter(source -> source.fallbackScale),
		Codec.DOUBLE.optionalFieldOf("inner_radius", SanctuaryWorldgenOptions.DEFAULT_INNER_RADIUS).forGetter(source -> source.innerRadius),
		Codec.DOUBLE.optionalFieldOf("outer_radius", SanctuaryWorldgenOptions.DEFAULT_OUTER_RADIUS).forGetter(source -> source.outerRadius)
	).apply(instance, (
		fallback,
		meadow,
		birchForest,
		forest,
		flowerForest,
		sunflowerPlains,
		windsweptHills,
		options,
		fallbackScale,
		legacyInnerRadius,
		legacyOuterRadius
	) -> new SanctuaryBiomeSource(
		fallback,
		meadow,
		birchForest,
		forest,
		flowerForest,
		sunflowerPlains,
		windsweptHills,
		options.orElse(SanctuaryWorldgenOptions.fromLegacy(meadow, legacyInnerRadius, legacyOuterRadius)),
		fallbackScale
	)));

	private final class_6880<class_8197> fallback;
	private final class_6880<class_1959> meadow;
	private final class_6880<class_1959> birchForest;
	private final class_6880<class_1959> forest;
	private final class_6880<class_1959> flowerForest;
	private final class_6880<class_1959> sunflowerPlains;
	private final class_6880<class_1959> windsweptHills;
	private final SanctuaryWorldgenOptions options;
	private final double innerRadius;
	private final double outerRadius;
	private final double fallbackScale;
	private final class_4766 fallbackSource;

	public SanctuaryBiomeSource(
		class_6880<class_8197> fallback,
		class_6880<class_1959> meadow,
		class_6880<class_1959> birchForest,
		class_6880<class_1959> forest,
		class_6880<class_1959> flowerForest,
		class_6880<class_1959> sunflowerPlains,
		class_6880<class_1959> windsweptHills,
		SanctuaryWorldgenOptions options,
		double fallbackScale
	) {
		this.fallback = fallback;
		this.meadow = meadow;
		this.birchForest = birchForest;
		this.forest = forest;
		this.flowerForest = flowerForest;
		this.sunflowerPlains = sunflowerPlains;
		this.windsweptHills = windsweptHills;
		this.options = options.sanitized(meadow);
		this.innerRadius = this.options.innerRadius();
		this.outerRadius = Math.max(this.options.outerRadius(), this.innerRadius + 32.0D);
		this.fallbackScale = Math.max(0.1D, Math.min(1.0D, fallbackScale));
		this.fallbackSource = class_4766.method_49503(fallback);
	}

	@Override
	protected MapCodec<? extends class_1966> method_28442() {
		return CODEC;
	}

	@Override
	protected Stream<class_6880<class_1959>> method_49494() {
		return Stream.concat(
			Stream.of(this.options.starterBiome(), this.meadow, this.birchForest, this.forest, this.flowerForest, this.sunflowerPlains, this.windsweptHills),
			this.fallbackSource.method_28443().stream()
		).distinct();
	}

	@Override
	public class_6880<class_1959> method_38109(int quartX, int quartY, int quartZ, class_6544.class_6552 sampler) {
		int blockX = quartX << 2;
		int blockZ = quartZ << 2;
		return this.sampleSanctuaryBiome(
			quartX,
			quartY,
			quartZ,
			sampler,
			blockX,
			blockZ,
			this.options,
			this.innerRadius,
			this.outerRadius
		);
	}

	private class_6880<class_1959> sampleSanctuaryBiome(
		int quartX,
		int quartY,
		int quartZ,
		class_6544.class_6552 sampler,
		double localBlockX,
		double localBlockZ,
		SanctuaryWorldgenOptions activeOptions,
		double activeInnerRadius,
		double activeOuterRadius
	) {
		double distance = SanctuaryWorldgen.distanceToOrigin(localBlockX, localBlockZ);
		double archipelagoSize = activeOptions.archipelagoSize();
		double starterIslandScale = activeOptions.starterIslandScale();
		double archipelagoSpacing = activeOptions.archipelagoSpacing();
		double monolithGapScale = activeOptions.monolithGapScale();
		double outerRadiusScale = clamp(
			1.0D - archipelagoSpacing * 0.45D + (monolithGapScale - 1.0D) * 0.45D,
			0.72D,
			1.90D
		);
		double activeSanctuaryOuterRadius = activeOuterRadius * outerRadiusScale;
		double activeSanctuaryInnerRadius = Math.min(
			activeSanctuaryOuterRadius - 24.0D,
			activeInnerRadius * clamp(1.0D - archipelagoSpacing * 0.20D, 0.82D, 1.18D)
		);
		double patchFrequencyScale = 1.0D / Math.max(0.35D, archipelagoSize);
		double sampleX = localBlockX * patchFrequencyScale;
		double sampleZ = localBlockZ * patchFrequencyScale;
		double edgeFallbackThreshold = clamp(0.18D + archipelagoSpacing * 0.18D, 0.05D, 0.32D);
		if (distance >= activeSanctuaryOuterRadius) {
			return this.sampleFallbackBiome(quartX, quartY, quartZ, sampler, activeOptions);
		}

		class_6544.class_6553 point = sampler.method_40444(quartX, quartY, quartZ);
		double temperature = class_6544.method_38666(point.comp_112());
		double humidity = class_6544.method_38666(point.comp_113());
		double sanctuaryBias = 1.0D - smoothstep(activeSanctuaryInnerRadius, activeSanctuaryOuterRadius, distance);

		if (sanctuaryBias <= 0.0D) {
			return this.sampleFallbackBiome(quartX, quartY, quartZ, sampler, activeOptions);
		}

		if (sanctuaryBias < edgeFallbackThreshold) {
			return this.sampleFallbackBiome(quartX, quartY, quartZ, sampler, activeOptions);
		}

		if (!this.usesCuratedSanctuaryPalette(activeOptions.starterBiome())) {
			double fullStarterBiomeRadius = Math.max(
				72.0D,
				activeSanctuaryInnerRadius * clamp(0.88D + (starterIslandScale - 1.0D) * 0.55D, 0.58D, 1.35D)
			);
			if (distance < fullStarterBiomeRadius || sanctuaryBias >= edgeFallbackThreshold + 0.10D) {
				return activeOptions.starterBiome();
			}

			return this.sampleFallbackBiome(quartX, quartY, quartZ, sampler, activeOptions);
		}

		double centralMeadowRadius = activeSanctuaryInnerRadius * starterIslandScale * (
			0.28D
				+ 0.06D * Math.sin(sampleX * 0.008D)
				+ 0.04D * Math.cos(sampleZ * 0.007D)
		);
		centralMeadowRadius = Math.max(40.0D, centralMeadowRadius);
		if (distance < centralMeadowRadius) {
			return activeOptions.starterBiome();
		}

		double patchA = 0.50D
			+ 0.22D * Math.sin(sampleX * 0.010D + humidity * 2.6D)
			+ 0.17D * Math.cos(sampleZ * 0.012D - temperature * 1.7D)
			+ 0.10D * Math.sin((sampleX - sampleZ) * 0.006D);
		double patchB = 0.49D
			+ 0.18D * Math.cos(sampleX * 0.009D - humidity * 1.9D)
			+ 0.15D * Math.sin(sampleZ * 0.010D + temperature * 2.3D)
			+ 0.08D * Math.cos((sampleX + sampleZ) * 0.005D);
		double ridgeBand = 0.45D
			+ 0.24D * Math.sin((sampleX + sampleZ) * 0.008D)
			+ 0.16D * Math.cos((sampleX - sampleZ) * 0.011D)
			- 0.10D * humidity;
		double blossomBand = 0.43D
			+ 0.19D * Math.sin(sampleX * 0.013D)
			+ 0.17D * Math.cos(sampleZ * 0.014D)
			+ 0.08D * humidity;
		double sunflowerBand = 0.42D
			+ 0.20D * Math.cos(sampleX * 0.011D + 0.8D)
			+ 0.14D * Math.sin(sampleZ * 0.010D - 0.6D)
			+ 0.09D * temperature;
		double edgeBias = smoothstep(
			activeSanctuaryInnerRadius * 0.50D,
			activeSanctuaryOuterRadius * (0.96D + Math.max(0.0D, archipelagoSpacing) * 0.16D),
			distance
		);

		if (edgeBias > 0.42D && ridgeBand > 0.58D) {
			return this.windsweptHills;
		}

		if (blossomBand > 0.60D && humidity > -0.22D) {
			return this.flowerForest;
		}

		if (sunflowerBand > 0.59D && temperature > -0.15D && edgeBias < 0.62D) {
			return this.sunflowerPlains;
		}

		if (patchB > 0.53D || temperature > 0.14D) {
			return this.forest;
		}

		if (patchA > 0.44D || humidity > 0.10D) {
			return this.birchForest;
		}

		return this.meadow;
	}

	private class_6880<class_1959> sampleFallbackBiome(int quartX, int quartY, int quartZ, class_6544.class_6552 sampler) {
		return this.sampleFallbackBiome(quartX, quartY, quartZ, sampler, this.options);
	}

	private class_6880<class_1959> sampleFallbackBiome(
		int quartX,
		int quartY,
		int quartZ,
		class_6544.class_6552 sampler,
		SanctuaryWorldgenOptions activeOptions
	) {
		double sizeScale = 1.0D / Math.max(0.35D, activeOptions.archipelagoSize());
		double spacingScale = 1.0D - activeOptions.archipelagoSpacing() * 0.35D;
		double effectiveFallbackScale = clamp(this.fallbackScale * sizeScale * spacingScale, 0.12D, 1.40D);
		int scaledQuartX = scaleQuartCoord(quartX, effectiveFallbackScale);
		int scaledQuartZ = scaleQuartCoord(quartZ, effectiveFallbackScale);
		return this.fallbackSource.method_38109(scaledQuartX, quartY, scaledQuartZ, sampler);
	}

	public SanctuaryBiomeSource withOptions(SanctuaryWorldgenOptions updatedOptions) {
		return new SanctuaryBiomeSource(
			this.fallback,
			this.meadow,
			this.birchForest,
			this.forest,
			this.flowerForest,
			this.sunflowerPlains,
			this.windsweptHills,
			updatedOptions,
			this.fallbackScale
		);
	}

	public SanctuaryWorldgenOptions options() {
		return this.options;
	}

	public class_6880<class_8197> fallback() {
		return this.fallback;
	}

	public class_6880<class_1959> meadow() {
		return this.meadow;
	}

	public class_6880<class_1959> birchForest() {
		return this.birchForest;
	}

	public class_6880<class_1959> forest() {
		return this.forest;
	}

	public class_6880<class_1959> flowerForest() {
		return this.flowerForest;
	}

	public class_6880<class_1959> sunflowerPlains() {
		return this.sunflowerPlains;
	}

	public class_6880<class_1959> windsweptHills() {
		return this.windsweptHills;
	}

	public double fallbackScale() {
		return this.fallbackScale;
	}

	public List<class_6880<class_1959>> getStartingBiomeCandidates() {
		LinkedHashMap<String, class_6880<class_1959>> candidatesByKey = new LinkedHashMap<>();
		addCandidate(candidatesByKey, this.options.starterBiome());
		addCandidate(candidatesByKey, this.meadow);
		addCandidate(candidatesByKey, this.birchForest);
		addCandidate(candidatesByKey, this.forest);
		addCandidate(candidatesByKey, this.flowerForest);
		addCandidate(candidatesByKey, this.sunflowerPlains);
		addCandidate(candidatesByKey, this.windsweptHills);

		for (class_6880<class_1959> biome : this.fallbackSource.method_28443()) {
			addCandidate(candidatesByKey, biome);
		}

		List<class_6880<class_1959>> candidates = new ArrayList<>(candidatesByKey.values());
		class_6880<class_1959> selectedStarterBiome = this.options.starterBiome();
		candidates.sort(Comparator.comparing(SanctuaryBiomeSource::biomeSortKey));
		if (candidates.remove(selectedStarterBiome)) {
			candidates.add(0, selectedStarterBiome);
		}

		return candidates;
	}

	public static boolean isSurfaceSafeStartBiome(class_6880<class_1959> biome) {
		if (!biome.method_40220(class_6908.field_37393)
			|| biome.method_40220(class_6908.field_36518)
			|| biome.method_40220(class_6908.field_37394)
			|| biome.method_40220(class_6908.field_36509)
			|| biome.method_40220(class_6908.field_36508)
			|| biome.method_40220(class_6908.field_36511)
			|| biome.method_40220(class_6908.field_36510)) {
			return false;
		}

		String path = biomePath(biome);
		return !path.contains("cave")
			&& !path.contains("void")
			&& !path.contains("underground")
			&& !path.contains("basalt")
			&& !path.contains("delta");
	}

	public static boolean supportsStarterTrees(class_6880<class_1959> biome) {
		if (!isSurfaceSafeStartBiome(biome)) {
			return false;
		}

		String path = biomePath(biome);
		return biome.method_40220(class_6908.field_36517)
			|| biome.method_40220(class_6908.field_36515)
			|| biome.method_40220(class_6908.field_36516)
			|| biome.method_40220(class_6908.field_37392)
			|| path.contains("plains")
			|| path.contains("meadow")
			|| path.contains("grove");
	}

	public static boolean isLushStarterBiome(class_6880<class_1959> biome) {
		if (!supportsStarterTrees(biome)) {
			return false;
		}

		String path = biomePath(biome);
		return !path.contains("snow")
			&& !path.contains("frozen")
			&& !path.contains("desert")
			&& !path.contains("badlands")
			&& !path.contains("stony");
	}

	public static class_2561 getBiomeDisplayName(class_6880<class_1959> biome) {
		return biome
			.method_40230()
			.map(key -> {
				String translationKey = class_156.method_646("biome", key.method_29177());
				String fallbackName = humanizePath(key.method_29177().method_12832());
				return class_2561.method_48321(translationKey, fallbackName);
			})
			.orElse(class_2561.method_43470("Unknown biome"));
	}

	private static int scaleQuartCoord(int coord, double scale) {
		return (int) Math.floor(coord * scale);
	}

	private static double smoothstep(double edge0, double edge1, double value) {
		double t = Math.max(0.0D, Math.min(1.0D, (value - edge0) / (edge1 - edge0)));
		return t * t * (3.0D - 2.0D * t);
	}

	private static double clamp(double value, double min, double max) {
		return Math.max(min, Math.min(max, value));
	}

	private static void addCandidate(LinkedHashMap<String, class_6880<class_1959>> candidatesByKey, class_6880<class_1959> biome) {
		if (biome == null || !isSurfaceSafeStartBiome(biome)) {
			return;
		}

		candidatesByKey.putIfAbsent(biomeKey(biome), biome);
	}

	private static String biomeSortKey(class_6880<class_1959> biome) {
		return biome.method_40230().map(key -> key.method_29177().toString()).orElse("unknown");
	}

	private boolean usesCuratedSanctuaryPalette(class_6880<class_1959> biome) {
		return biome != null && biome.method_55838(this.meadow);
	}

	private static String biomeKey(class_6880<class_1959> biome) {
		return biome.method_40230().map(key -> key.method_29177().toString()).orElse("unknown:" + biome.hashCode());
	}

	private static String biomePath(class_6880<class_1959> biome) {
		return biome.method_40230().map(key -> key.method_29177().method_12832()).orElse("");
	}

	private static String humanizePath(String path) {
		String[] parts = path.split("_");
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < parts.length; i++) {
			if (parts[i].isEmpty()) {
				continue;
			}

			if (builder.length() > 0) {
				builder.append(' ');
			}

			builder.append(Character.toUpperCase(parts[i].charAt(0)));
			if (parts[i].length() > 1) {
				builder.append(parts[i].substring(1));
			}
		}

		return builder.isEmpty() ? path : builder.toString();
	}
}
