package com.koka.sanctuary.worldgen;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3195;
import net.minecraft.class_4966;
import net.minecraft.class_5539;
import net.minecraft.class_7138;
import net.minecraft.class_7151;

public final class SanctuaryStructureRules {
	private static final int[][] SUPPORT_SAMPLE_OFFSETS = {
		{4, 4},
		{12, 4},
		{4, 12},
		{12, 12},
		{8, 8}
	};
	private static final int MIN_TERRAIN_HEIGHT_ABOVE_BOTTOM = 16;
	private static final int SUPPORT_SCAN_DEPTH = 48;
	private static final StructureProfile DEFAULT_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		2,
		1,
		24,
		6,
		14,
		0,
		4,
		0
	);
	private static final StructureProfile SETTLEMENT_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		4,
		0,
		36,
		7,
		12,
		0,
		4,
		0
	);
	private static final StructureProfile MONUMENT_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		3,
		1,
		32,
		8,
		16,
		0,
		5,
		0
	);
	private static final StructureProfile PORTAL_PROFILE = new StructureProfile(
		AnchorMode.KEEP,
		3,
		0,
		28,
		7,
		12,
		0,
		4,
		0
	);
	private static final StructureProfile SUBTERRANEAN_PROFILE = new StructureProfile(
		AnchorMode.INTERIOR,
		3,
		2,
		44,
		12,
		20,
		14,
		8,
		64
	);
	private static final StructureProfile BURIED_PROFILE = new StructureProfile(
		AnchorMode.INTERIOR,
		3,
		0,
		18,
		6,
		10,
		4,
		3,
		20
	);

	private SanctuaryStructureRules() {
	}

	public static Optional<class_3195.class_7150> adapt(class_3195 structure, class_3195.class_7149 context, class_3195.class_7150 position) {
		if (!SanctuaryWorldgen.isSanctuaryGenerator(context.comp_562())) {
			return Optional.of(position);
		}

		StructureProfile profile = profileFor(structure);
		TerrainReport terrain = analyzeTerrain(context, profile);
		if (!terrain.isSupported(profile)) {
			return Optional.empty();
		}

		class_2338 originalPos = position.comp_571();
		int adjustedY = switch (profile.anchorMode()) {
			case KEEP -> originalPos.method_10264();
			case INTERIOR -> computeInteriorAnchorY(profile, terrain, originalPos.method_10264());
		};
		if (adjustedY == originalPos.method_10264()) {
			return Optional.of(position);
		}

		class_2338 adjustedPos = new class_2338(originalPos.method_10263(), adjustedY, originalPos.method_10260());
		return Optional.of(new class_3195.class_7150(adjustedPos, position.comp_572()));
	}

	private static StructureProfile profileFor(class_3195 structure) {
		class_7151<?> type = structure.method_41618();
		if (type == class_7151.field_37759 || type == class_7151.field_37765) {
			return SUBTERRANEAN_PROFILE;
		}
		if (type == class_7151.field_37752) {
			return BURIED_PROFILE;
		}
		if (type == class_7151.field_37757) {
			return SETTLEMENT_PROFILE;
		}
		if (
			type == class_7151.field_37753
				|| type == class_7151.field_37758
				|| type == class_7151.field_37756
				|| type == class_7151.field_37766
				|| type == class_7151.field_37767
				|| type == class_7151.field_37761
				|| type == class_7151.field_37762
				|| type == class_7151.field_37764
		) {
			return MONUMENT_PROFILE;
		}
		if (type == class_7151.field_37763) {
			return PORTAL_PROFILE;
		}

		return DEFAULT_PROFILE;
	}

	private static TerrainReport analyzeTerrain(class_3195.class_7149 context, StructureProfile profile) {
		class_2794 chunkGenerator = context.comp_562();
		class_1923 chunkPos = context.comp_568();
		class_5539 world = context.comp_569();
		class_7138 noiseConfig = context.comp_564();
		int bottomY = world.method_31607();
		List<TerrainSample> samples = new ArrayList<>(SUPPORT_SAMPLE_OFFSETS.length);
		int supportedColumns = 0;
		int deepColumns = 0;
		int totalThickness = 0;
		int surfaceYSum = 0;
		int surfaceYCount = 0;
		TerrainSample bestSurfaceSample = null;
		TerrainSample bestDeepSample = null;

		for (int[] sampleOffset : SUPPORT_SAMPLE_OFFSETS) {
			int sampleX = chunkPos.method_8326() + sampleOffset[0];
			int sampleZ = chunkPos.method_8328() + sampleOffset[1];
			int topY = chunkGenerator.method_18028(sampleX, sampleZ, class_2902.class_2903.field_13194, world, noiseConfig);
			if (topY <= bottomY + MIN_TERRAIN_HEIGHT_ABOVE_BOTTOM) {
				continue;
			}

			int thickness = measureSurfaceThickness(chunkGenerator.method_26261(sampleX, sampleZ, world, noiseConfig), topY - 1, bottomY);
			TerrainSample sample = new TerrainSample(sampleX, sampleZ, topY, thickness);
			samples.add(sample);
			surfaceYSum += topY;
			surfaceYCount++;

			if (thickness >= profile.minSurfaceThickness()) {
				supportedColumns++;
				if (bestSurfaceSample == null || thickness > bestSurfaceSample.thickness()) {
					bestSurfaceSample = sample;
				}
			}

			if (thickness >= profile.minDeepSurfaceThickness()) {
				deepColumns++;
				if (bestDeepSample == null || thickness > bestDeepSample.thickness()) {
					bestDeepSample = sample;
				}
			}

			totalThickness += thickness;
		}

		int averageSurfaceY = surfaceYCount == 0 ? bottomY : Math.round((float) surfaceYSum / surfaceYCount);
		return new TerrainReport(bottomY, supportedColumns, deepColumns, totalThickness, averageSurfaceY, bestSurfaceSample, bestDeepSample, samples);
	}

	private static int computeInteriorAnchorY(StructureProfile profile, TerrainReport terrain, int originalY) {
		TerrainSample anchorSample = terrain.bestDeepSample() != null ? terrain.bestDeepSample() : terrain.bestSurfaceSample();
		if (anchorSample == null) {
			return originalY;
		}

		int maxInset = Math.max(profile.surfaceCover(), anchorSample.thickness() - profile.surfaceCover());
		int inset = Math.min(profile.targetInset(), maxInset);
		int targetY = anchorSample.topY() - inset;
		int maxRaisedY = originalY + profile.maxRaise();
		return Math.min(Math.max(originalY, targetY), maxRaisedY);
	}

	private static int measureSurfaceThickness(class_4966 sample, int topBlockY, int bottomY) {
		int minY = Math.max(bottomY, topBlockY - SUPPORT_SCAN_DEPTH);
		int thickness = 0;

		for (int y = topBlockY; y >= minY; y--) {
			if (!sample.method_32892(y).method_51366()) {
				break;
			}

			thickness++;
		}

		return thickness;
	}

	private enum AnchorMode {
		KEEP,
		INTERIOR
	}

	private record StructureProfile(
		AnchorMode anchorMode,
		int minSupportedColumns,
		int minDeepColumns,
		int minTotalThickness,
		int minSurfaceThickness,
		int minDeepSurfaceThickness,
		int targetInset,
		int surfaceCover,
		int maxRaise
	) {
	}

	private record TerrainSample(int x, int z, int topY, int thickness) {
	}

	private record TerrainReport(
		int bottomY,
		int supportedColumns,
		int deepColumns,
		int totalThickness,
		int averageSurfaceY,
		TerrainSample bestSurfaceSample,
		TerrainSample bestDeepSample,
		List<TerrainSample> samples
	) {
		private boolean isSupported(StructureProfile profile) {
			return supportedColumns >= profile.minSupportedColumns()
				&& (deepColumns >= profile.minDeepColumns() || totalThickness >= profile.minTotalThickness());
		}
	}
}
