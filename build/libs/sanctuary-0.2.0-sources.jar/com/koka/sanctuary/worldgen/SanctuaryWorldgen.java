package com.koka.sanctuary.worldgen;

import net.minecraft.class_2794;
import net.minecraft.class_3754;
import net.minecraft.class_7723;

public final class SanctuaryWorldgen {
	public static final double ADVANCED_WORLDGEN_START_DISTANCE = 10_000_000.0D;
	public static final double ADVANCED_WORLDGEN_TRANSITION_WIDTH = 4_096.0D;

	private SanctuaryWorldgen() {
	}

	public static boolean isSanctuaryDimensions(class_7723 dimensions) {
		return isSanctuaryGenerator(dimensions.method_45513());
	}

	public static boolean isSanctuaryGenerator(class_2794 generator) {
		return generator instanceof class_3754 noiseGenerator
			&& noiseGenerator.method_12098() instanceof SanctuaryBiomeSource;
	}

	public static SanctuaryBiomeSource getSanctuaryBiomeSource(class_2794 generator) {
		if (generator instanceof class_3754 noiseGenerator
			&& noiseGenerator.method_12098() instanceof SanctuaryBiomeSource sanctuaryBiomeSource) {
			return sanctuaryBiomeSource;
		}

		throw new IllegalArgumentException("Chunk generator is not a Sanctuary generator");
	}

	public static boolean usesAdvancedWorldgen(double distanceFromOrigin) {
		return distanceFromOrigin >= ADVANCED_WORLDGEN_START_DISTANCE;
	}

	public static double distanceToOrigin(double blockX, double blockZ) {
		return Math.sqrt(blockX * blockX + blockZ * blockZ);
	}

	public static SanctuaryShellCoordinates projectToAdvancedShell(double blockX, double blockZ) {
		double worldDistance = distanceToOrigin(blockX, blockZ);
		double angle = Math.atan2(blockZ, blockX);
		double localDistance = Math.max(0.0D, worldDistance - ADVANCED_WORLDGEN_START_DISTANCE);
		double localBlockX = Math.cos(angle) * localDistance;
		double localBlockZ = Math.sin(angle) * localDistance;
		return new SanctuaryShellCoordinates(worldDistance, localDistance, localBlockX, localBlockZ);
	}
}
