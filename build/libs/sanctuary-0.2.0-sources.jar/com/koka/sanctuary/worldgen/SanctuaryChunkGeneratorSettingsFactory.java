package com.koka.sanctuary.worldgen;

import com.koka.sanctuary.SanctuaryMod;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3754;
import net.minecraft.class_5284;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5843;
import net.minecraft.class_6686;
import net.minecraft.class_6880;
import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_6953;
import net.minecraft.class_7723;
import net.minecraft.class_7924;

	public final class SanctuaryChunkGeneratorSettingsFactory {
		private static final double EPSILON = 1.0E-4D;
		private static final double VANILLA_ISLANDS_BLEND_WIDTH = 192.0D;
		private static final class_5843 DEEPSLATE_CORE_Y = class_5843.method_33841(104);
	private static final class_5321<class_6910> END_BASE_3D_NOISE_KEY = class_5321.method_29179(
		class_7924.field_41240,
		class_2960.method_60656("end/base_3d_noise")
	);

	private SanctuaryChunkGeneratorSettingsFactory() {
	}

	public static class_3754 createGenerator(
		class_5455.class_6890 registryManager,
		class_7723 selectedDimensions,
		SanctuaryWorldgenOptions options
	) {
		if (!(selectedDimensions.method_45513() instanceof class_3754 currentGenerator)) {
			throw new IllegalArgumentException("Selected dimensions do not use a noise chunk generator");
		}

		SanctuaryBiomeSource currentSource = SanctuaryWorldgen.getSanctuaryBiomeSource(currentGenerator);
		SanctuaryWorldgenOptions sanitizedOptions = options.sanitized(currentSource.meadow());
		class_6880<class_5284> baseSettings = resolveBaseSettings(registryManager, currentGenerator);
		class_6880<class_5284> effectiveSettings = hasCustomTerrainTuning(sanitizedOptions)
			? class_6880.method_40223(createCustomSettings(baseSettings.comp_349(), sanitizedOptions))
			: baseSettings;
		return new class_3754(currentSource.withOptions(sanitizedOptions), effectiveSettings);
	}

	private static class_6880<class_5284> resolveBaseSettings(
		class_5455.class_6890 registryManager,
		class_3754 currentGenerator
	) {
		class_2378<class_5284> settingsRegistry = registryManager.method_30530(class_7924.field_41243);
		return settingsRegistry
			.method_46746(SanctuaryMod.SANCTUARY_NOISE_SETTINGS)
			.map(entry -> (class_6880<class_5284>) entry)
			.orElse(currentGenerator.method_41541());
	}

	private static class_5284 createCustomSettings(
		class_5284 baseSettings,
		SanctuaryWorldgenOptions options
	) {
		class_6953 adjustedRouter = createCustomNoiseRouter(baseSettings.comp_477(), options);
		class_2680 defaultBlock = baseSettings.comp_475();
		class_6686.class_6708 surfaceRule = createSurfaceRule(baseSettings.comp_478(), options);
		return new class_5284(
			baseSettings.comp_474(),
			defaultBlock,
			baseSettings.comp_476(),
			adjustedRouter,
			surfaceRule,
			baseSettings.comp_538(),
			baseSettings.comp_479(),
			baseSettings.comp_480(),
			baseSettings.comp_481(),
			baseSettings.comp_482(),
			baseSettings.comp_483()
		);
	}

	private static class_6686.class_6708 createSurfaceRule(class_6686.class_6708 baseRule, SanctuaryWorldgenOptions options) {
		if (!options.deepslateCore()) {
			return baseRule;
		}

		return class_6686.method_39050(
			class_6686.method_39049(
				class_6686.method_39048(class_6686.field_35223),
				class_6686.method_39049(
					class_6686.method_39048(class_6686.method_39058(DEEPSLATE_CORE_Y, 0)),
					class_6686.method_39047(class_2246.field_28888.method_9564())
				)
			),
			baseRule
		);
	}

	private static class_6953 createCustomNoiseRouter(class_6953 baseRouter, SanctuaryWorldgenOptions options) {
		class_6953 scaledRouter = baseRouter.method_41544(new class_6910.class_6915() {
			@Override
			public class_6910 apply(class_6910 densityFunction) {
				if (densityFunction instanceof OriginIslandDensityFunction origin) {
					return origin.radialOffset() > 0.0D
						? OriginIslandDensityFunction.createShellTuned(origin.radialOffset(), options)
						: OriginIslandDensityFunction.createTuned(options);
				}

				return densityFunction;
			}
		});

		class_6910 adjustedFinalDensity = scaledRouter.comp_487().method_40469(new class_6910.class_6915() {
			@Override
			public class_6910 apply(class_6910 densityFunction) {
				if (densityFunction instanceof class_6916.class_7051 holder
					&& holder.comp_468().method_40225(END_BASE_3D_NOISE_KEY)) {
					return gateVanillaFloatingIslands(holder, options);
				}

				return densityFunction;
			}
		});
		double archipelagoMultiplier = clamp(
			1.0D + (options.archipelagoSize() - 1.0D) * 0.32D - options.archipelagoSpacing() * 0.12D,
			0.75D,
			1.35D
		);
		double archipelagoBias = clamp(
			(options.archipelagoSize() - 1.0D) * 0.12D - options.archipelagoSpacing() * 0.28D,
			-0.35D,
			0.28D
		);
		if (Math.abs(archipelagoMultiplier - 1.0D) > EPSILON) {
			adjustedFinalDensity = class_6916.method_40500(
				adjustedFinalDensity,
				class_6916.method_40480(archipelagoMultiplier)
			);
		}

		if (Math.abs(archipelagoBias) > EPSILON) {
			adjustedFinalDensity = class_6916.method_40486(
				adjustedFinalDensity,
				class_6916.method_40480(archipelagoBias)
			);
		}

		return new class_6953(
			scaledRouter.comp_414(),
			scaledRouter.comp_415(),
			scaledRouter.comp_416(),
			scaledRouter.comp_417(),
			scaledRouter.comp_420(),
			scaledRouter.comp_539(),
			scaledRouter.comp_484(),
			scaledRouter.comp_423(),
			scaledRouter.comp_424(),
			scaledRouter.comp_485(),
			scaledRouter.comp_4450(),
			adjustedFinalDensity,
			scaledRouter.comp_428(),
			scaledRouter.comp_429(),
			scaledRouter.comp_430()
		);
	}

	private static boolean hasCustomTerrainTuning(SanctuaryWorldgenOptions options) {
		return Math.abs(options.starterIslandScale() - SanctuaryWorldgenOptions.DEFAULT_STARTER_ISLAND_SCALE) > EPSILON
			|| Math.abs(options.archipelagoSize() - SanctuaryWorldgenOptions.DEFAULT_ARCHIPELAGO_SIZE) > EPSILON
			|| Math.abs(options.archipelagoSpacing() - SanctuaryWorldgenOptions.DEFAULT_ARCHIPELAGO_SPACING) > EPSILON
			|| options.effectiveVanillaFloatingIslandsStartRadius() != SanctuaryWorldgenOptions.DEFAULT_VANILLA_FLOATING_ISLANDS_START_RADIUS
			|| options.satelliteIslands() != SanctuaryWorldgenOptions.DEFAULT_SATELLITE_ISLANDS
			|| options.verticalityProfile() != SanctuaryWorldgenOptions.DEFAULT_VERTICALITY_PROFILE
			|| options.mainIslandPreset() != SanctuaryWorldgenOptions.DEFAULT_MAIN_ISLAND_PRESET
			|| Math.abs(options.monolithMassHeight() - SanctuaryWorldgenOptions.DEFAULT_MONOLITH_MASS_HEIGHT) > EPSILON
			|| Math.abs(options.monolithShoulderWidth() - SanctuaryWorldgenOptions.DEFAULT_MONOLITH_SHOULDER_WIDTH) > EPSILON
			|| options.fracturedIslandCount() != SanctuaryWorldgenOptions.DEFAULT_FRACTURED_ISLAND_COUNT
			|| Math.abs(options.fracturedRingRadius() - SanctuaryWorldgenOptions.DEFAULT_FRACTURED_RING_RADIUS) > EPSILON
			|| Math.abs(options.hollowVoidSize() - SanctuaryWorldgenOptions.DEFAULT_HOLLOW_VOID_SIZE) > EPSILON
			|| Math.abs(options.hollowRingThickness() - SanctuaryWorldgenOptions.DEFAULT_HOLLOW_RING_THICKNESS) > EPSILON
			|| options.spireCount() != SanctuaryWorldgenOptions.DEFAULT_SPIRE_COUNT
			|| Math.abs(options.spireHeight() - SanctuaryWorldgenOptions.DEFAULT_SPIRE_HEIGHT) > EPSILON
			|| options.deepslateCore() != SanctuaryWorldgenOptions.DEFAULT_DEEPSLATE_CORE;
	}

	private static class_6910 gateVanillaFloatingIslands(class_6910 densityFunction, SanctuaryWorldgenOptions options) {
		int startRadius = options.effectiveVanillaFloatingIslandsStartRadius();
		if (startRadius <= 0) {
			return densityFunction;
		}

		return class_6916.method_40500(
			densityFunction,
			new OriginDistanceRampDensityFunction(startRadius, startRadius + VANILLA_ISLANDS_BLEND_WIDTH)
		);
	}

	private static double clamp(double value, double min, double max) {
		return Math.max(min, Math.min(max, value));
	}
}
