package com.koka.sanctuary.mixin;

import com.koka.sanctuary.worldgen.SanctuaryStructureRules;
import java.util.Optional;
import net.minecraft.class_3195;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3195.class)
abstract class StructureMixin {
	@Inject(method = "getValidStructurePosition", at = @At("RETURN"), cancellable = true)
	private void sanctuary$adaptStructuresToFloatingIslands(
		class_3195.class_7149 context,
		CallbackInfoReturnable<Optional<class_3195.class_7150>> cir
	) {
		Optional<class_3195.class_7150> result = cir.getReturnValue();
		if (result.isEmpty()) {
			return;
		}

		class_3195 self = (class_3195) (Object) this;
		cir.setReturnValue(SanctuaryStructureRules.adapt(self, context, result.get()));
	}
}
