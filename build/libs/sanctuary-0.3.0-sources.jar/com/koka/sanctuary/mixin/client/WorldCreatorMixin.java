package com.koka.sanctuary.mixin.client;

import com.koka.sanctuary.SanctuaryMod;
import com.koka.sanctuary.client.SanctuaryClient;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_5293;
import net.minecraft.class_7145;
import net.minecraft.class_8100;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8100.class)
abstract class WorldCreatorMixin {
	@Inject(method = "getLevelScreenProvider", at = @At("HEAD"), cancellable = true)
	private void sanctuary$provideCustomScreen(CallbackInfoReturnable<class_5293> cir) {
		class_8100 worldCreator = (class_8100) (Object) this;
		if (worldCreator.method_48730().comp_1238() != null
			&& worldCreator.method_48730().comp_1238().method_40225(SanctuaryMod.SANCTUARY_WORLD_PRESET)) {
			cir.setReturnValue(SanctuaryClient.SANCTUARY_LEVEL_SCREEN_PROVIDER);
		}
	}

	@Redirect(
		method = "updateWorldTypeLists",
		at = @At(value = "INVOKE", target = "Ljava/util/Map;get(Ljava/lang/Object;)Ljava/lang/Object;")
	)
	private Object sanctuary$keepSanctuaryPresetStable(
		Map<Optional<net.minecraft.class_5321<class_7145>>, class_5293> providers,
		Object key
	) {
		Object provider = providers.get(key);
		if (provider != null) {
			return provider;
		}

		return isSanctuaryWorldPresetKey(key) ? SanctuaryClient.SANCTUARY_LEVEL_SCREEN_PROVIDER : null;
	}

	private static boolean isSanctuaryWorldPresetKey(Object key) {
		if (!(key instanceof Optional<?> optionalKey) || optionalKey.isEmpty()) {
			return false;
		}

		return SanctuaryMod.SANCTUARY_WORLD_PRESET.equals(optionalKey.get());
	}
}
