package com.koka.sanctuary.mixin.client;

import com.koka.sanctuary.SanctuaryMod;
import com.koka.sanctuary.worldgen.SanctuaryWorldgen;
import java.util.Optional;
import net.minecraft.class_5317;
import net.minecraft.class_5321;
import net.minecraft.class_7145;
import net.minecraft.class_7723;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5317.class)
abstract class WorldPresetsMixin {
	@Inject(method = "getWorldPreset", at = @At("HEAD"), cancellable = true)
	private static void sanctuary$recognizeCustomSanctuaryWorlds(
		class_7723 dimensions,
		CallbackInfoReturnable<Optional<class_5321<class_7145>>> cir
	) {
		if (SanctuaryWorldgen.isSanctuaryDimensions(dimensions)) {
			cir.setReturnValue(Optional.of(SanctuaryMod.SANCTUARY_WORLD_PRESET));
		}
	}
}
