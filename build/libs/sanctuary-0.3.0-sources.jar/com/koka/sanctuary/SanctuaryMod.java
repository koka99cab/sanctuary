package com.koka.sanctuary;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2960;
import net.minecraft.class_5284;
import net.minecraft.class_5321;
import net.minecraft.class_7145;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class SanctuaryMod implements ModInitializer {
	public static final String MOD_ID = "sanctuary";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final class_5321<class_7145> SANCTUARY_WORLD_PRESET = class_5321.method_29179(
		class_7924.field_41250,
		id("sanctuary")
	);
	public static final class_5321<class_5284> SANCTUARY_NOISE_SETTINGS = class_5321.method_29179(
		class_7924.field_41243,
		id("sanctuary_overworld")
	);

	@Override
	public void onInitialize() {
		SanctuaryRegistries.register();
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
