package com.koka.sanctuary.worldgen;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_6910;
import net.minecraft.class_7243;

public record OriginDistanceDensityFunction() implements class_6910.class_6913 {
	public static final OriginDistanceDensityFunction INSTANCE = new OriginDistanceDensityFunction();
	public static final double MAX_DISTANCE = 43_000_000.0D;
	public static final MapCodec<OriginDistanceDensityFunction> MAP_CODEC = MapCodec.unit(INSTANCE);

	@SuppressWarnings("unchecked")
	public static final class_7243<class_6910> CODEC_HOLDER = class_7243.method_42116((MapCodec<class_6910>) (MapCodec<?>) MAP_CODEC);

	@Override
	public double method_40464(class_6910.class_6912 context) {
		double x = context.comp_371();
		double z = context.comp_373();
		return Math.sqrt(x * x + z * z);
	}

	@Override
	public double comp_377() {
		return 0.0D;
	}

	@Override
	public double comp_378() {
		return MAX_DISTANCE;
	}

	@Override
	public class_7243<? extends class_6910> method_41062() {
		return CODEC_HOLDER;
	}
}
