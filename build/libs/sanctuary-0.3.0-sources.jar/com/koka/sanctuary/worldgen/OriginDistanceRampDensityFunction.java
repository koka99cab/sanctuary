package com.koka.sanctuary.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_6910;
import net.minecraft.class_7243;

public record OriginDistanceRampDensityFunction(double startRadius, double endRadius) implements class_6910.class_6913 {
	public static final double MAX_DISTANCE = OriginDistanceDensityFunction.MAX_DISTANCE;
	public static final MapCodec<OriginDistanceRampDensityFunction> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
		Codec.DOUBLE.fieldOf("start_radius").forGetter(OriginDistanceRampDensityFunction::startRadius),
		Codec.DOUBLE.fieldOf("end_radius").forGetter(OriginDistanceRampDensityFunction::endRadius)
	).apply(instance, OriginDistanceRampDensityFunction::new));

	@SuppressWarnings("unchecked")
	public static final class_7243<class_6910> CODEC_HOLDER = class_7243.method_42116((MapCodec<class_6910>) (MapCodec<?>) MAP_CODEC);

	public OriginDistanceRampDensityFunction {
		startRadius = Math.max(0.0D, startRadius);
		endRadius = Math.max(startRadius + 1.0D, endRadius);
	}

	@Override
	public double method_40464(class_6910.class_6912 context) {
		double distance = SanctuaryWorldgen.noisyDistanceToOrigin(context.comp_371(), context.comp_373());
		if (distance <= this.startRadius) {
			return 0.0D;
		}

		if (distance >= this.endRadius) {
			return 1.0D;
		}

		double t = (distance - this.startRadius) / (this.endRadius - this.startRadius);
		return t * t * (3.0D - 2.0D * t);
	}

	@Override
	public double comp_377() {
		return 0.0D;
	}

	@Override
	public double comp_378() {
		return 1.0D;
	}

	@Override
	public class_7243<? extends class_6910> method_41062() {
		return CODEC_HOLDER;
	}
}
