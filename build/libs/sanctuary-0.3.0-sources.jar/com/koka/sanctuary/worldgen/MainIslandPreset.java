package com.koka.sanctuary.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.class_3542;

public enum MainIslandPreset implements class_3542 {
	MONOLITH("monolith"),
	FRACTURED_ARCHIPELAGO("fractured_archipelago"),
	HOLLOW_CROWN("hollow_crown"),
	SPIRE_GARDEN("spire_garden");

	public static final Codec<MainIslandPreset> CODEC = class_3542.method_28140(MainIslandPreset::values);

	private final String id;

	MainIslandPreset(String id) {
		this.id = id;
	}

	@Override
	public String method_15434() {
		return this.id;
	}
}
