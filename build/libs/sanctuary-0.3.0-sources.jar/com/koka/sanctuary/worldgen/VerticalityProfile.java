package com.koka.sanctuary.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.class_3542;

public enum VerticalityProfile implements class_3542 {
	PLATEAU("plateau"),
	BALANCED("balanced"),
	VARIED("varied");

	public static final Codec<VerticalityProfile> CODEC = class_3542.method_28140(VerticalityProfile::values);

	private final String id;

	VerticalityProfile(String id) {
		this.id = id;
	}

	@Override
	public String method_15434() {
		return this.id;
	}
}
