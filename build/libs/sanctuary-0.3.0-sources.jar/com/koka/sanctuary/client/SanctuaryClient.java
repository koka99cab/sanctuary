package com.koka.sanctuary.client;

import com.koka.sanctuary.client.gui.SanctuaryCustomizeScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_5293;

public final class SanctuaryClient implements ClientModInitializer {
	public static final class_5293 SANCTUARY_LEVEL_SCREEN_PROVIDER = SanctuaryCustomizeScreen::new;

	@Override
	public void onInitializeClient() {
	}
}
