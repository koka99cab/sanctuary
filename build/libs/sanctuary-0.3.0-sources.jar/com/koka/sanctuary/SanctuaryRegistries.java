package com.koka.sanctuary;

import com.koka.sanctuary.worldgen.OriginDistanceDensityFunction;
import com.koka.sanctuary.worldgen.OriginDistanceRampDensityFunction;
import com.koka.sanctuary.worldgen.OriginIslandDensityFunction;
import com.koka.sanctuary.worldgen.SanctuaryBiomeSource;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class SanctuaryRegistries {
	private static boolean registered;

	private SanctuaryRegistries() {
	}

	public static void register() {
		if (registered) {
			return;
		}

		registered = true;
		class_2378.method_10230(class_7923.field_41156, SanctuaryMod.id("sanctuary_biome_source"), SanctuaryBiomeSource.CODEC);
		class_2378.method_10230(class_7923.field_41160, SanctuaryMod.id("origin_island_field"), OriginIslandDensityFunction.CODEC_HOLDER.comp_640());
		class_2378.method_10230(class_7923.field_41160, SanctuaryMod.id("origin_distance"), OriginDistanceDensityFunction.CODEC_HOLDER.comp_640());
		class_2378.method_10230(class_7923.field_41160, SanctuaryMod.id("origin_distance_ramp"), OriginDistanceRampDensityFunction.CODEC_HOLDER.comp_640());
	}
}
